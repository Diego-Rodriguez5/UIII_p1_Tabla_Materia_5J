from django.contrib import admin
from .models import Proveedores

# Register your models here.

admin.site.register(Proveedores)