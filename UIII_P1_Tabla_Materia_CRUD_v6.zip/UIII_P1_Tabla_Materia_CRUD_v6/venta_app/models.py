from django.db import models

# Create your models here.

class Venta(models.Model):
    idVenta=models.CharField(primary_key=True, max_length=20)
    fechaVenta=models.DateField()
    total=models.FloatField()
    idCliente=models.CharField(max_length=20)
    idEmpleado=models.CharField(max_length=20)
    tipoPago=models.CharField(max_length=20)
    descuento=models.FloatField()
    idProducto=models.CharField(max_length=20)
    cantidad=models.CharField(max_length=500)

    def __str__(self):
        return self.total